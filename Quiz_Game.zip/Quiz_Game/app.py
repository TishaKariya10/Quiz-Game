from flask import Flask, request, redirect, url_for, render_template

app = Flask(__name__)

questions = [
    "Q1. Who developed Python?",
    "Q2. Python is ____ typed language?",
    "Q3. Which symbol is used for comments?",
    "Q4. Output of print(2**3)?",
    "Q5. Which converts string to int?",
    "Q6. Python file extension?",
    "Q7. Which is keyword?",
    "Q8. Which creates list?",
    "Q9. Output of 10//3?",
    "Q10. Operator for power?",
    "Q11. Which is mutable?",
    "Q12. len('hello')?",
    "Q13. Used for input?",
    "Q14. Python created in year?",
    "Q15. Creator of Flask?"
]

options = [
    ["A. Guido van Rossum","B. Elon Musk","C. Bill Gates","D. Newton"],
    ["A. Static","B. Dynamic","C. Compiler","D. Machine"],
    ["A. //","B. #","C. !","D. %"],
    ["A. 5","B. 6","C. 8","D. 16"],
    ["A. int()","B. str()","C. float()","D. chr()"],
    ["A. .pt","B. .py","C. .p","D. .txt"],
    ["A. car","B. apple","C. for","D. ball"],
    ["A. {}","B. []","C. ()","D. <>"],
    ["A. 3.33","B. 3","C. 4","D. 10"],
    ["A. ^","B. **","C. //","D. =="],
    ["A. Tuple","B. String","C. List","D. Int"],
    ["A. 3","B. 4","C. 5","D. 6"],
    ["A. scan()","B. input()","C. get()","D. take()"],
    ["A. 1980","B. 1991","C. 2000","D. 2010"],
    ["A. Elon","B. Linus","C. Armin Ronacher","D. Guido"]
]

answers = ["A","B","B","C","A","B","C","B","B","B","C","C","B","B","C"]

score = 0


@app.route("/")
def start():
    global score
    score = 0
    return redirect(url_for("question", qno=0))


@app.route("/question/<int:qno>", methods=["GET", "POST"])
def question(qno):
    global score

    # If user submitted an answer
    if request.method == "POST":
        selected = request.form.get("answer")

        if selected == answers[qno - 1]:
            score = score + 1

        # GO TO NEXT QUESTION
        return redirect(url_for("question", qno=qno + 1))

    # If all questions answered → show results page
    if qno == 15:
        return render_template("result.html", score=score)

    return render_template("question.html",
                           question=questions[qno],
                           options=options[qno],
                           qno=qno)
    

app.run(debug=True)
